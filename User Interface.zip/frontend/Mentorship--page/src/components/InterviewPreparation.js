import React from 'react';

const InterviewPreparation = () => {
  return (
    <div className="interview-preparation-page">
      <h1>Interview Preparation</h1>
      <p>Resources and tips to help you prepare for your interviews.</p>
    </div>
  );
};

export default InterviewPreparation;
