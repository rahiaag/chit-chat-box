import React from 'react';

const About = () => {
  return (
    <div className="about-page">
      <h1>About Us</h1>
      <p>Learn more about the platform and its mission to help students succeed.</p>
    </div>
  );
};

export default About;
