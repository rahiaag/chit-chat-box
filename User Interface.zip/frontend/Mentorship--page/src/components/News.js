import React from 'react';

const News = () => {
  return (
    <div className="news-page">
      <h1>News</h1>
      <p>Latest news and updates for students and professionals.</p>
    </div>
  );
};

export default News;
