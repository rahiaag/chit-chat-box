import React from 'react';

const Trending = () => {
  return (
    <div className="trending-page">
      <h1>Trending</h1>
      <p>Content for the Trending page goes here.</p>
    </div>
  );
};

export default Trending;
